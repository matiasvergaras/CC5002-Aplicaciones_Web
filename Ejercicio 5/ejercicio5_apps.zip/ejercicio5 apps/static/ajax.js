/**
 * Imprime error
 * @param {string|number} msg
 */
function mostrarError(msg) {

    let contenedor = document.getElementById('error');

    contenedor.innerHTML = msg;
    contenedor.style.display = 'block';
    contenedor.style.fontWeight = '800';

}

/**
 * Chequea si un número es entero
 * @param value
 * @returns {boolean}
 */
function isInt(value) {
    let x = parseFloat(value);
    return !isNaN(value) && (x | 0) === x;
}

/**
 Envío del formulario
 */
function enviarFormulario() {

    // Este string va concatenando los errores
    let msgError = '';

    /**
     Validacion nombre
     */
    let nombre = document.getElementById('nombre-medico').value;
    let regex = /^[a-zA-Z ]*$/;
    if (nombre.length < 4 || nombre.length > 100 || !regex.test(nombre)) {
        msgError += 'Nombre no cumple restricción de extensión (mínimo 4, máximo 100) - ';
    }

    /**
     Validacion experiencia
     */
    let exp = document.getElementById('experiencia-medico').value;
    if (exp.length < 4 || exp.length > 200) {
        msgError += 'Experiencia no cumple restricción de extensión (mínimo 4, máximo 200) - ';
    }


    /**
     * Validación edad
     */
    let celular = document.getElementById('celular-medico').value;
    if (!isInt(celular) || parseInt(celular) <= 0 || celular.length !== 9 ) {
        msgError += 'Celular incorrecto - '
    }

    /**
     Validacion mail
     */
    let mail = document.getElementById('email-medico').value;
    let regmail = /^[^\s@]+@[^\s@]+$/;
    if (mail.length < 4 || mail.length > 30 || !regmail.test(mail)) {
        msgError += 'Email incorrecto - ';
    }

    /**
     Validacion especialidad
     */
    let especialidades = ['Cardiología', 'Gastroenterología', 'Endocrinología', 'Epidemiología',
                          'Geriatría', 'Hematología', 'Infectología', 'Medicina del Deporte', 'Medicina de urgencias',
                          'Medicina interna', 'Nefrología', 'Neumología', 'Neurología', 'Nutriología', 'Oncología',
                          'Pediatría', 'Psiquiatría', 'Psiqiatría', 'Reumatología', 'Toxicología', 'Dermatología',
                          'Ginecología', 'Oftalmología', 'Otorrinolaringología', 'Urología', 'Traumatología']
    let especialidad = document.getElementById('especialidad-medico').value;
    if (!(especialidades.includes(especialidad))) {
        msgError += 'Especialidad incorrecta ' + especialidad;
    }

    /**
     Validacion archivo
     */
    if (document.getElementById('foto-medico').files.length === 0) {
        msgError += ', Archivo no adjunto ';
    }

    /**
     Mostramos el error y retornamos el estado de la validacion
     */
    if (msgError.length > 0) {
        mostrarError('Tu formulario fallo en: ' + msgError);
        return false;
    }

    /**
     * Envío de ajax
     */
    console.log('Enviando formulario');
    let data = new FormData();
    data.append('nombre-medico', nombre);
    data.append('experiencia-medico', exp);
    data.append('especialidad-medico', especialidad);
    data.append('foto-medico', document.getElementById('foto-medico').files[0]);
    data.append('email-medico', mail);
    data.append('celular-medico', celular);

    let xhr = new XMLHttpRequest();
    xhr.open('POST', 'save_doctor.py', true);
    xhr.timeout = 300;
    xhr.onload = function (data) {
        alert('Enviado correctamente!');
        console.warn(data.currentTarget.responseText);
    };
    xhr.onerror = function () {
        mostrarError('No se pudo enviar el mensaje');
    }

    xhr.send(data);
    return false;

}

function writeDoctor(nombre, experiencia, especialidad, fotografia, email, celular) {
    let cont = document.getElementById('table-docs');
    cont.innerHTML += `
    <tr>
        <td>${nombre}</td>
        <td>${experiencia}</td>
        <td>${especialidad}</td>
        <td><img class="foto-doctor" src="../media/${fotografia}" style="max-width: 120px; max-height: 120px"></td>
        <td>${email}</td>
        <td>${celular}</td>
    </tr>
    `;
}

function loadDoctors() {
    console.log('Cargando doctores desde el servidor');
    let xhr = new XMLHttpRequest();
    xhr.open('GET', 'list-ajax.py');
    xhr.timeout = 1000; // 1 segundo máximo
    xhr.onload = function (data) {
        // noinspection JSUnresolvedVariable
        /** @type {string} */ let datatext = data.currentTarget.responseText;
        if (datatext.includes('ERROR') || datatext.includes('Error')) {
            mostrarError('Error en el servidor');
            return;
        }
        let doctores = JSON.parse(datatext);
        let keys = Object.keys(doctores);
        keys = keys.reverse();
        let cont = document.getElementById('content-doctores')
        if (keys.length > 0){
            cont.innerHTML  = `
               <div style="padding:0 16px;">
              <h2>Listado de médicos registrados</h2>
              <table>
              <tbody  id="table-docs">
              <tr>
              <th>Nombre</th>
              <th>Experiencia</th>
              <th>Especialidad</th>
              <th>Fotografía</th>
              <th>Email</th>
              <th>Celular</th>
              </tr>`;
            for (let i = 0; i < keys.length; i += 1) {
                let key = keys[i];
                if (doctores.hasOwnProperty(key)) {
                    writeDoctor(doctores[key][0], doctores[key][1], doctores[key][3], doctores[key][2],
                                doctores[key][4], doctores[key][5]);
                }
            }
            cont.innerHTML += '</tbody> </table>'
            }
        else {
            cont.innerHTML = `
            <h2>Aún no hay médicos registrados</h2>
            `
        }
    }
    xhr.ontimeout = function () {
        mostrarError('Se excedió el tiempo máximo de comunicación con el servidor');
    }
    xhr.onerror = function () {
        mostrarError('Error al cargar los mensajes desde la base de datos');
    }
    xhr.send();
}
