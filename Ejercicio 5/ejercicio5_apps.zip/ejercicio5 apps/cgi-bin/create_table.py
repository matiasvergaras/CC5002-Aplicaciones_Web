#!/usr/bin/python3
# -*- coding: utf-8 -*-
import mysql.connector

cnx = mysql.connector.connect(
    host="localhost",
    user="root",
    password=""
)

cursor = cnx.cursor()

filesql = open("../ejercicio4.sql", "r")

cursor.execute(filesql.read(), multi=True).send(None)
