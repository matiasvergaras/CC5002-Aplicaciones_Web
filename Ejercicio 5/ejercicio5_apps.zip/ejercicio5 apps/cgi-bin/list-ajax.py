#!/usr/bin/python3
# -*- coding: utf-8 -*-

import cgi
import cgitb
import json
from db import Doctor
import mysql.connector

cgitb.enable()

print("Content-type:text/html\r\n\r\n")

utf8stdout = open(1, 'w', encoding='utf-8', closefd=False)

docdb = Doctor(host="localhost", user="root", password="", database="ejercicio4")

try:
    data = docdb.get_doctors()
    fotos = docdb.get_photos()
    doctores = {}
    k = 0
    for i in data:
        for d in range(0, len(data)):
            for p in range(0, len(fotos)):
                if fotos[p][0] == data[d][3]:
                    doctores[k] = [None, None, None, None, None, None]
                    doctores[k][0] = str(data[d][1])
                    doctores[k][1] = str(data[d][2])
                    doctores[k][2] = str(fotos[p][2])
                    doctores[k][3] = str(data[d][4])
                    doctores[k][4] = str(data[d][5])
                    doctores[k][5] = str(data[d][6])
        k += 1
    print(json.dumps(doctores))

except mysql.connector.Error as err:
    print('ERROR CONEXION AL LEER')
