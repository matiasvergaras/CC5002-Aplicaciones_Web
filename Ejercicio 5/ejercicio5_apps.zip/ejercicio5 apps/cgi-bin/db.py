#!/usr/bin/python3
# -*- coding: utf-8 -*-
import mysql.connector
import os
import filetype
from utils import imprimeerror
import hashlib

MAX_FILE_SIZE = 10000 * 1000 # 10 MB v

class Doctor:

    def __init__(self, host, user, password, database):
        self.db = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database
        )
        self.cursor = self.db.cursor()

    def save_doctor(self, data):
        #procesar y guardar el archivo
        fileobj = data[3]
        filename = fileobj.filename

        if not filename:
            imprimeerror(10, 'Error: Archivo no subido')

        # verificamos el tipo
        size = os.fstat(fileobj.file.fileno()).st_size
        if size > MAX_FILE_SIZE:
            imprimeerror(1000, 'Error: El archivo excede el tamaño máximo permitido de 10 MB')

        # calculamos cuantos elementos existen y actualizamos el hash
        sql = "SELECT COUNT(id) FROM media"
        self.cursor.execute(sql)
        total = self.cursor.fetchall()[0][0] + 1
        hash_archivo = str(total) + hashlib.sha256(filename.encode()).hexdigest()[0:30]

        # guardar el archivo
        file_path = 'media/' + hash_archivo
        open(file_path, 'wb').write(fileobj.file.read())

        # verificamos el tipo, si no es valido lo borramos de la db
        tipo = filetype.guess(file_path)
        if tipo.mime != 'image/jpg' and tipo.mime != 'image/png' and tipo.mime != 'image/jpeg':
            os.remove(file_path)
            imprimeerror(40, 'Error: Tipo archivo no es jpg ni png')

        # guardamos la imagen en la db
        sql = """
            INSERT INTO media (nombre, path)
            VALUES (%s, %s);
        """

        self.cursor.execute(sql, (filename, hash_archivo))
        self.db.commit()  # id
        id_foto = self.cursor.getlastrowid()

        sql = """
            INSERT INTO medico (nombre, experiencia, especialidad, foto, email, celular)
            VALUES (%s, %s, %s, %s, %s, %s);
        """
        fields = [ data[0], data[1], data[2], id_foto, data[4], data[5]]
        self.cursor.execute(sql, fields)
        self.db.commit()


    def get_doctors(self):
        sql = f"""
        SELECT * FROM medico
        """
        self.cursor.execute(sql)
        return self.cursor.fetchall()

    def get_photos(self):
        sql = f"""
        SELECT * FROM media 
        """
        self.cursor.execute(sql)
        return self.cursor.fetchall()


