#!/usr/bin/python3
# -*- coding: utf-8 -*-


import cgi
import cgitb
from db import Doctor
cgitb.enable()

print("Content-type:text/html\r\n\r\n")

utf8stdout = open(1, 'w', encoding='utf-8', closefd=False)

form = cgi.FieldStorage()
docdb = Doctor(host="localhost", user="root", password="", database="ejercicio4")

fileobj = form['foto-medico']

data = (
    form['nombre-medico'].value, form['experiencia-medico'].value,
    form['especialidad-medico'].value, fileobj,
    form['email-medico'].value, form['celular-medico'].value
)

docdb.save_doctor(data)

tf8stdout = open(1, 'w', encoding='utf-8', closefd=False)


content= """
<div style="padding:0 16px;">
  <h2>¡Datos recibidos con éxito!</h2>
"""

renamed_keys = {"nombre-medico": "Nombre del médico", "celular-medico": "Número celular", "experiencia-medico": "Experiencia",
                "foto-medico": "Nombre del archivo fotografía del profesional",
                "especialidad-medico": "Especialidad", "email-medico": "Dirección de correo electrónico"}

for key in form.keys():
    if key != 'foto-medico':
        content += "<p>" + str(renamed_keys[key]) + ": " + str(form[key].value) + "</p>"
    else:
        content += "<p>" + str(renamed_keys[key]) + ": " + form[key].filename + "</p>"

with open('static/template.html', 'r', encoding='utf-8') as file:
    s = file.read()
    print(s.format('Información enviada', content), file=utf8stdout)


