#!C:/Users/m_jvs/AppData/Local/Programs/Python/Python39/python
# -*- coding: utf-8 -*-

print('Content-type: text/html\r\n\r\n')

utf8stdout = open(1, 'w', encoding='utf-8', closefd=False)

with open('static/template.html', 'r', encoding='utf-8') as file:
    s = file.read()
    print(s.format('Doctores - E4', """
       <!-- Body of page -->
    <h1>Agregar datos de un médico</h1>
    <form id="myform" method="post" action="save_doctor.py"
    enctype='multipart/form-data'">
      
      <!-- Label for nombre médico -->
      <br>
      <label for="nombre-medico" class="text-field">Nombre (*)</label>
      <br> 
      <input type="text" id="nombre-medico" name="nombre-medico" size="20" maxlength="30" placeholder="Nombre del médico" >
      <br>

      <!-- Label for experiencia-medico -->
      <br>
      <label for="experiencia-medico" class="text-field">Experiencia (*)</label>
      <br>
      <textarea rows="8" cols="40" id="experiencia-medico" name="experiencia-medico" placeholder="Ingrese experiencia del médico."></textarea>
      <br>
      <br>

      <!-- Label for Especialidades -->
      <label for="especialidad-medico" class="text-field">Especialidad del médico (*)</label>
      <br>
      <select id="especialidad-medico" name="especialidad-medico" >
        <option value="Cardiología">Cardiología</option>
        <option value="Gastroenterología">Gastroenterología</option>
        <option value="Endocrinología">Endocrinología</option>
        <option value="Epidemiología">Epidemiología</option>
        <option value="Geriatría">Geriatría</option>
        <option value="Hematología">Hematología</option>
        <option value="Infectología">Infectología</option>
        <option value="Medicina del Deporte">Medicina del Deporte</option>
        <option value="Medicina de urgencias">Medicina de urgencias</option>
        <option value="Medicina interna">Medicina interna</option>
        <option value="Nefrología">Nefrología</option>
        <option value="Neumología">Neumología</option>
        <option value="Neurología">Neurología</option>
        <option value="Nutriología">Nutriología</option>
        <option value="Oncología">Oncología</option>
        <option value="Pediatría">Pediatría</option>
        <option value="Psiquiatría">Psiquiatría</option>
        <option value="Reumatología">Reumatología</option>
        <option value="Toxicología">Toxicología</option>
        <option value="Dermatología">Dermatología</option>
        <option value="Ginecología">Ginecología</option>
        <option value="Oftalmología">Oftalmología</option>
        <option value="Otorrinolaringología">Otorrinolaringología</option>
        <option value="Urología">Urología</option>
        <option value="Traumatología">Traumatología</option>
      </select>
      <br>



      <!-- Label for email contacto -->
      <br>
      <label for="email-medico" class="text-field">Email contacto (*)</label>
      <br>
      <input type="email" id="email-medico" name="email-medico" size="80" maxlength="80" placeholder="Correo electrónico" >
      <br>

      <!-- Label for número celular contacto -->
      <br>
      <label for="celular-medico" class="text-field">Celular contacto (*)</label>
      <br>
      <input type="tel" id="celular-medico" name="celular-medico" maxlength="20" placeholder="Correo electrónico">
      <br> 
    
    <br>
      <label for="foto-medico">Fotografía (.png/.jpg)</label>
      <br>
      <input type="file" id="foto-medico" name="foto-medico" accept="image/png, image/jpeg" >
      <br>
<br>

      <input type="submit" value="Crear datos del médico">
      <br>
      <br>
      </form>
    """), file=utf8stdout)
