#!/usr/bin/python3
# -*- coding: utf-8 -*-

import cgi
import cgitb
from db import Doctor

cgitb.enable()

print("Content-type:text/html\r\n\r\n")

utf8stdout = open(1, 'w', encoding='utf-8', closefd=False)

docdb = Doctor(host="localhost", user="root", password="", database="ejercicio4")
data = docdb.get_doctors()
fotos = docdb.get_photos()

body_table_1 = """
<div style="padding:0 16px;">
  <h2>Listado de médicos registrados</h2>
  <table>
  <tr>
  <th>Nombre</th>
  <th>Experiencia</th>
  <th>Especialidad</th>
  <th>Fotografía</th>
  <th>Email</th>
  <th>Celular</th>
  </tr>
"""

body_close_table = """
</table>
"""
content = ""


with open('static/template.html', 'r', encoding='utf-8') as file:
    s = file.read()
    form = cgi.FieldStorage()
    if len(data) > 0:
        content += body_table_1
        for d in range(0, len(data)):
            for p in range(0, len(fotos)):
                if fotos[p][0] == data[d][3]:
                    print(fotos[p][2])
                    src = "../media/"+fotos[p][2]
                    row = f'''
                    <tr>
                        <th>{str(data[d][1])}</th>
                        <th>{str(data[d][2])}</th>
                        <th><img class="foto-doctor" src="../media/{str(fotos[p][2])}" style="max-width: 120px; max-height: 120px"></th>
                        <th>{str(data[d][4])}</th>
                        <th>{str(data[d][5])}</th>
                        <th>{str(data[d][6])}</th>
                    </tr>
                        '''
            content += row
        content += body_close_table
    else:
        content += "<h2>Aún no hay médicos registrados</h2>"
    print(s.format("Ver Médicos", content), file=utf8stdout)